<?php

$lang['cal_su']			= "НЯ";
$lang['cal_mo']			= "ДА";
$lang['cal_tu']			= "МЯ";
$lang['cal_we']			= "ЛХ";
$lang['cal_th']			= "ПҮ";
$lang['cal_fr']			= "БА";
$lang['cal_sa']			= "БЯ";
$lang['cal_sun']		= "НЯМ";
$lang['cal_mon']		= "ДАВ";
$lang['cal_tue']		= "МЯГ";
$lang['cal_wed']		= "ЛХА";
$lang['cal_thu']		= "ПҮР";
$lang['cal_fri']		= "БАА";
$lang['cal_sat']		= "БЯМ";
$lang['cal_sunday']		= "Ням";
$lang['cal_monday']		= "Даваа";
$lang['cal_tuesday']	= "Мягмар";
$lang['cal_wednesday']	= "Лхагва";
$lang['cal_thursday']	= "Пүрэв";
$lang['cal_friday']		= "Баасан";
$lang['cal_saturday']	= "Бямба";
$lang['cal_jan']		= "1-р сар";
$lang['cal_feb']		= "2-р сар";
$lang['cal_mar']		= "3-р сар";
$lang['cal_apr']		= "4-р сар";
$lang['cal_may']		= "5-р сар";
$lang['cal_jun']		= "6-р сар";
$lang['cal_jul']		= "7-р сар";
$lang['cal_aug']		= "8-р сар";
$lang['cal_sep']		= "9-р сар";
$lang['cal_oct']		= "10-р сар";
$lang['cal_nov']		= "11-р сар";
$lang['cal_dec']		= "12-р сар";
$lang['cal_january']	= "1-р сар";
$lang['cal_february']	= "2-р сар";
$lang['cal_march']		= "3-р сар";
$lang['cal_april']		= "4-р сар";
$lang['cal_mayl']		= "5-р сар";
$lang['cal_june']		= "6-р сар";
$lang['cal_july']		= "7-р сар";
$lang['cal_august']		= "8-р сар";
$lang['cal_september']	= "9-р сар";
$lang['cal_october']	= "10-р сар";
$lang['cal_november']	= "11-р сар";
$lang['cal_december']	= "12-р сар";


/* End of file calendar_lang.php */
/* Location: ./system/language/english/calendar_lang.php */