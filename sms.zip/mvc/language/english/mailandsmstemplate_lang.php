<?php

/* List Language  */
$lang['panel_title'] = "Mail / SMS Template";
$lang['add_title'] = "Add a template";
$lang['slno'] = "#";
$lang['mailandsmstemplate_name'] = "Name";
$lang['mailandsmstemplate_user'] = "User";
$lang['mailandsmstemplate_tags'] = "Tags";
$lang['mailandsmstemplate_template'] = "Template";
$lang['mailandsmstemplate_select_user'] = "Select User";
$lang['mailandsmstemplate_student'] = "Student";
$lang['mailandsmstemplate_parents'] = "Parents";
$lang['mailandsmstemplate_teacher'] = "Teacher";
$lang['mailandsmstemplate_accountant'] = "Accountant";
$lang['mailandsmstemplate_librarian'] = "Librarian";
$lang['mailandsmstemplate_type'] = "Type";
$lang['mailandsmstemplate_select_type'] = "Select Type";
$lang['mailandsmstemplate_email'] = "Email";
$lang['mailandsmstemplate_sms'] = "SMS";
$lang['mailandsmstemplate_select_tag'] = "Select Tag";
$lang['action'] = "Action";
$lang['view'] = 'View';
$lang['edit'] = 'Edit';
$lang['delete'] = 'Delete';
$lang['add_template'] = 'Add Template';
$lang['update_template'] = 'Update Template';