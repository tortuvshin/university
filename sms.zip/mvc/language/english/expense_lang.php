<?php

/* List Language  */
$lang['panel_title'] = "Expense";
$lang['add_title'] = "Add a expense";
$lang['slno'] = "#";
$lang['expense_expense'] = "Name";
$lang['expense_date'] = "Date";
$lang['expense_amount'] = "Amount";
$lang['expense_note'] = "Note";
$lang['expense_uname'] = "User";
$lang['expense_total'] = "Total";
$lang['action'] = "Action";

// $lang['view'] = 'View';
$lang['edit'] = 'Edit';
$lang['delete'] = 'Delete';

/* Add Language */

$lang['add_expense'] = 'Add Expense';
$lang['update_expense'] = 'Update Expense';