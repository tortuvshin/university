<?php

/* List Language  */
$lang['panel_title'] = "Mail / SMS ";
$lang['add_title'] = "Add a mail / sms";
$lang['slno'] = "#";
$lang['mailandsms_users'] = "Users";
$lang['mailandsms_select_user'] = "Select Users";
$lang['mailandsms_select_template'] = "Select Template";
$lang['mailandsms_select_send_by'] = "Select Send By";
$lang['mailandsms_students'] = "Students";
$lang['mailandsms_parents'] = "Parents";
$lang['mailandsms_teachers'] = "Teachers";
$lang['mailandsms_librarians'] = "Librarians";
$lang['mailandsms_accountants'] = "Accountants";
$lang['mailandsms_template'] = "Template";
$lang['mailandsms_type'] = "Type";
$lang['mailandsms_email'] = "Email";
$lang['mailandsms_sms'] = "SMS";
$lang['mailandsms_getway'] = 'Send By';
$lang['mailandsms_subject'] = 'Subject';
$lang['mailandsms_message'] = "Message";
$lang['mailandsms_dateandtime'] = "Date and Time";


$lang['mailandsms_clickatell'] = "Clickatell";
$lang['mailandsms_twilio'] = "Twilio";
$lang['mailandsms_bulk'] = "Bulk";


$lang['action'] = "Action";
$lang['view'] = 'View';
$lang['send'] = "Send";
$lang['mail_success'] = 'Email send successfully!';
$lang['mail_error'] = 'oops! Email not send!';
$lang['mail_error_user'] = 'oops! User list is empty!';





