<?php

/* List Language  */
$lang['panel_title'] = "Notice";
$lang['add_title'] = "Add a notice";
$lang['slno'] = "#";
$lang['notice_title'] = "Title";
$lang['notice_notice'] = "Notice";
$lang['notice_date'] = "Date";
$lang['action'] = "Action";

$lang['view'] = 'View';
$lang['edit'] = 'Edit';
$lang['delete'] = 'Delete';
$lang['print'] = 'Print';
$lang['pdf_preview'] = 'PDF Preview';
$lang["mail"] = "Send Pdf to Mail";

/* Add Language */

$lang['add_class'] = 'Add Notice';
$lang['update_class'] = 'Update Notice';

$lang['to'] = 'To';
$lang['subject'] = 'Subject';
$lang['message'] = 'Message';
$lang['send'] = 'Send';
$lang['mail_to'] = "The To field is required.";
$lang['mail_valid'] = "The To field must contain a valid email address.";
$lang['mail_subject'] = "The Subject field is required.";
$lang['mail_success'] = 'Email send successfully!';
$lang['mail_error'] = 'oops! Email not send!';