<?php

/* List Language  */
$lang['panel_title'] = "Fee Type";
$lang['add_title'] = "Add a Fee Type";
$lang['slno'] = "#";
$lang['feetype_name'] = "Fee Type";
$lang['feetype_note'] = "Note";
$lang['action'] = "Action";

$lang['edit'] = 'Edit';
$lang['delete'] = 'Delete';

/* Add Language */
$lang['add_feetype'] = 'Add Fee Type';
$lang['update_feetype'] = 'Update Fee Type';