<?php

/* List Language  */
$lang['panel_title'] = "Message";
$lang['add_title'] = "Compose";
$lang['folder'] = "Folders";
$lang['inbox'] = "Inbox";
$lang['to'] = "To";
$lang['status'] = "Status";
$lang['name'] = "Name";
$lang['subject'] = "Subject";
$lang['attach'] = "Attach";
$lang['time'] = "Time";
$lang['sent'] = "Sent";
$lang['trash'] = "Trash";
$lang['favorite'] = "Favorite";
$lang['slno'] = "#";
$lang['message_title'] = "Title";
$lang['message_message'] = "Message";
$lang['message_date'] = "Date";
$lang['action'] = "Action";
$lang['read_message'] = "Read Message";
$lang['reply'] = "Reply";
$lang['compose_new'] = "Compose New Message";
$lang['admin_select_label'] = "Admin list";
$lang['student_select_label'] = "Students list";
$lang['parent_select_label'] = "Parents list";
$lang['teacher_select_label'] = "Teachers list";
$lang['librarian_select_label'] = "Librarians list";
$lang['accountant_select_label'] = "Accountants list";
$lang['attachment'] = "Attachment";
$lang['send'] = "Send";
$lang['close'] = "Close";
$lang['sender'] = "Sender";
$lang['discard'] = "Discard";
$lang['error'] = "Reply not sent!";
