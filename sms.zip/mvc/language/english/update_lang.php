<?php
$lang['panel_title'] = "Update";

$lang['update_file'] = "File";
$lang['update_update'] = "Update";



?>