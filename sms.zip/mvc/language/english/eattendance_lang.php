<?php

/* List Language  */
$lang['panel_title'] = "Exam Attendance";
$lang['add_title'] = "Add exam attendance";
$lang['slno'] = "#";
$lang['eattendance_photo'] = "Photo";
$lang['eattendance_name'] = "Name";
$lang['eattendance_email'] = "Email";
$lang['eattendance_roll'] = "Roll";
$lang['eattendance_phone'] = "Phone";
$lang['eattendance_attendance'] = "Attendance";
$lang['eattendance_section'] = "Section";
$lang['eattendance_exam'] = "Exam";
$lang['eattendance_classes'] = "Class";
$lang['eattendance_subject'] = "Subject";
$lang['eattendance_all_students'] = 'All Students';

$lang['eattendance_select_exam'] = "Select Exam";
$lang['eattendance_select_classes'] = "Select Class";
$lang['eattendance_select_subject'] = "Select Subject";


$lang['action'] = "Action";

/* Add Language */

$lang['add_attendance'] = 'Attendance';
$lang['add_all_attendance'] = 'Add All Attendance';
$lang['view_attendance'] = "View Attendance";