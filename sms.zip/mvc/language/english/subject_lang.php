<?php

/* List Language  */
$lang['panel_title'] = "Subject";
$lang['add_title'] = "Add a subject";
$lang['slno'] = "#";
$lang['subject_class_name'] = "Class Name";
$lang['subject_teacher_name'] = "Teacher Name";
$lang['subject_student'] = "Student";
$lang['subject_name'] = "Subject Name";
$lang['subject_author'] = "Subject Author";
$lang['subject_code'] = "Subject Code";
$lang['subject_teacher'] = "Teacher";
$lang['subject_classes'] = "Class";
$lang['subject_select_class'] = "Select Class";
$lang['subject_select_classes'] = "Select Class";
$lang['subject_select_teacher'] = "Select Teacher";
$lang['subject_select_student'] = "Select Student";




$lang['action'] = "Action";
$lang['view'] = 'View';
$lang['edit'] = 'Edit';
$lang['delete'] = 'Delete';

/* Add Language */

$lang['add_subject'] = 'Add subject';
$lang['update_subject'] = 'Update subject';