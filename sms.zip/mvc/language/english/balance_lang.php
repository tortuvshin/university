<?php

/* List Language  */
$lang['panel_title'] = "Balance";
$lang['slno'] = "#";
$lang['balance_classesID'] = "Class";
$lang['balance_select_classes'] = "Select Class";
$lang['balance_all_students'] = 'All Student';
$lang['balance_photo'] = "Photo";
$lang['balance_name'] = "Name";
$lang['balance_roll'] = "Roll";
$lang['balance_phone'] = "Phone";
$lang['balance_totalbalance'] = "Total Balance";