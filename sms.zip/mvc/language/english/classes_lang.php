<?php

/* List Language  */
$lang['panel_title'] = "Class";
$lang['add_title'] = "Add a class";
$lang['slno'] = "#";
$lang['classes_name'] = "Class";
$lang['classes_numeric'] = "Class Numeric";
$lang['teacher_name'] = "Teacher Name";
$lang['classes_note'] = "Note";
$lang['action'] = "Action";

$lang['classes_select_teacher'] = "Select Teacher";

$lang['view'] = 'View';
$lang['edit'] = 'Edit';
$lang['delete'] = 'Delete';

/* Add Language */

$lang['add_class'] = 'Add Class';
$lang['update_class'] = 'Update Class';