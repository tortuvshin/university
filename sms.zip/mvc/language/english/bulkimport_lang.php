<?php

/* List Language  */
$lang['panel_title'] = "Import";
$lang['add_title'] = "Add a Import";
$lang['slno'] = "#";
$lang['import_title'] = "Title";
$lang['import_import'] = "Import";
$lang['import_date'] = "Date";
$lang['bulkimport_teacher'] = "Add Teacher";
$lang['bulkimport_student'] = "Add Student";
$lang['bulkimport_parent'] = "Add Parent";
$lang['bulkimport_user'] = "Add User";
$lang['bulkimport_book'] = "Add Book";
$lang['bulkimport_submit'] = "Import";

/* Add Language */

$lang['add_class'] = 'Add Import';
$lang['upload_file'] = 'Import file';
$lang['import_file_type_error'] = 'Invalid file';
$lang['import_error'] = 'oops! data not imported, Please try again.';
$lang['import_success'] = 'Data successfully added';
$lang['bulkimport_sample'] = 'Download Sample';