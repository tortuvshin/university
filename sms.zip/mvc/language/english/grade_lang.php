<?php

/* List Language  */
$lang['panel_title'] = "Grade";
$lang['add_title'] = "Add a grade";
$lang['slno'] = "#";
$lang['grade_name'] = "Grade Name";
$lang['grade_point'] = "Grade Point";
$lang['grade_gradefrom'] = "Mark From";
$lang['grade_gradeupto'] = "Mark Upto";
$lang['grade_note'] = "Note";

$lang['action'] = "Action";
$lang['view'] = 'View';
$lang['edit'] = 'Edit';
$lang['delete'] = 'Delete';

/* Add Language */

$lang['add_class'] = 'Add Grade';
$lang['update_class'] = 'Update Grade';