<?php

$lang['panel_title'] = "Promotion";
$lang['add_title'] = "Add promotion";
$lang['slno'] = "#";
$lang['promotion_photo'] = "Photo";
$lang['promotion_name'] = "Name";
$lang['promotion_section'] = "section";
$lang['promotion_result'] = "Result";
$lang['promotion_pass'] = "Pass";
$lang['promotion_fail'] = "Fail";
$lang['promotion_modarate'] = "Not Yet";
$lang['promotion_phone'] = "Phone";
$lang['promotion_classes'] = "Class";
$lang['promotion_roll'] = "Roll";
$lang['promotion_create_class'] = "Please create a new class";
$lang['promotion_select_class'] = "Select Class";
$lang['promotion_select_student'] = "Select Student";
$lang['add_all_promotion'] = "All Promotion";
$lang['promotion_alert'] = "Alert";
$lang['promotion_ok'] = "Ok";
$lang['promotion_success'] = "Promotion Success";
$lang['promotion_emstudent'] = "Empty Student List";


$lang['action'] = "Action";

$lang['add_mark_setting'] = 'Promotion Mark Setting';
$lang['add_promotion'] = 'Promotion To Next Class';
