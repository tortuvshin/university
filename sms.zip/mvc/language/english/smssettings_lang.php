<?php

/* List Language  */
$lang['panel_title'] = "SMS Settings";
$lang['smssettings_username'] = "Username";
$lang['smssettings_password'] = "Password";
$lang['smssettings_api_key'] = "Api Key";

$lang['smssettings_accountSID'] = "AccountSID";
$lang['smssettings_authtoken'] = "Auth Token";
$lang['smssettings_fromnumber'] = "From Number";

$lang['save'] = "Save";





