<?php

/* List Language  */
$lang['panel_title'] = "Reset Password";
$lang['slno'] = "#";
$lang['reset_password_select_users'] = "Select Users";
$lang['reset_password_select_username'] = "Select Username";
$lang['reset_password_users'] = "Users";
$lang['reset_password_username'] = 'Username';
$lang['reset_password_new_password'] = 'New Password';
$lang['reset_password_re_password'] = 'Re-Password';

/* Add Language */

$lang['reset_password'] = 'Rseset Password';
$lang['update_class'] = 'Update Class';
