<?php

/* List Language  */
$lang['panel_title'] = "Media";
$lang['add_title'] = "Create Folder";
$lang['slno'] = "#";
$lang['media_title'] = "Title";
$lang['media_date'] = "Date";
$lang['action'] = "Action";

$lang['view'] = 'View';
$lang['edit'] = 'Edit';
$lang['delete'] = 'Delete';

/* Add Language */

$lang['add_class'] = 'Add media';
$lang['update_class'] = 'Update media';
$lang['file'] = 'Media';
$lang['upload_file'] = 'Upload media';
$lang['folder_name'] = 'Folder name';
$lang['share'] = 'Share';
$lang['share_with'] = 'Share with';
$lang['select_class'] = 'Select class';
$lang['all_class'] = 'All class';
$lang['public'] = 'Public';
$lang['class'] = 'Class';
