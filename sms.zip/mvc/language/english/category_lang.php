<?php

/* List Language  */
$lang['panel_title'] = "Category";
$lang['add_title'] = "Add a category";
$lang['slno'] = "#";
$lang['category_hname'] = "Hostel Name";
$lang['category_class_type'] = "Class Type";
$lang['category_hbalance'] = "Hostel Fee";
$lang['category_note'] = "Note";

$lang['category_select_hostel'] = "Select Hostel";

$lang['action'] = "Action";
$lang['edit'] = 'Edit';
$lang['delete'] = 'Delete';

/* Add Language */

$lang['add_category'] = 'Add Category';
$lang['update_category'] = 'Update Category';