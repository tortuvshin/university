<?php

/* List Language  */
$lang['panel_title'] = "Transport";
$lang['add_title'] = "Add a transport";
$lang['slno'] = "#";
$lang['transport_route'] = "Route Name";
$lang['transport_vehicle'] = "Number of Vehicle";
$lang['transport_fare'] = "Route Fare";
$lang['transport_note'] = "Note";

$lang['action'] = "Action";
$lang['view'] = 'View';
$lang['edit'] = 'Edit';
$lang['delete'] = 'Delete';

/* Add Language */

$lang['add_transport'] = 'Add transport';
$lang['update_transport'] = 'Update transport';