<?php

/* List Language  */
$lang['panel_title'] = "Backup";
$lang['slno'] = "#";
$lang['backup_title'] = "Backup Database";
$lang['backup_submit'] = "Download Sql";
