<?php

$lang['panel_title'] = "Profile";
$lang['profile_roll'] = "Roll";
$lang['profile_email'] = "Email";
$lang['profile_dob'] = "Date of Birth";
$lang['profile_jod'] = "Joining Date";
$lang['profile_sex'] = "Gender";
$lang['profile_religion'] = "Religion";
$lang['profile_phone'] = "Phone";
$lang['profile_address'] = "Address";

$lang['profile_guargian_name'] = "Guardian Name";
$lang['profile_father_name'] = "Father's Name";
$lang['profile_mother_name'] = "Mother's Name";
$lang['profile_father_profession'] = "Father's Profession";
$lang['profile_mother_profession'] = "Mother's Profession";
$lang['parent_error'] = "Parents have not been added yet! Please add parents information.";

$lang['personal_information'] = "Personal Information";
$lang['parents_information'] = "Parents Information";
