<?php
$lang['panel_title'] = "Dashboard";
$lang['dashboard_notice'] = "Notice";
$lang['dashboard_username'] = "Username";
$lang['dashboard_email'] = "Email";
$lang['dashboard_phone'] = "Phone";
$lang['dashboard_address'] = "Address";
$lang['dashboard_libraryfee'] = "Library Fee";
$lang['dashboard_transportfee'] = 'Transport Fee';
$lang['dashboard_hostelfee'] = 'Hostel Fee';

$lang['dashboard_earning_graph'] = "Earning Graph";
$lang['dashboard_notpaid'] = "Not Paid";
$lang['dashboard_partially_paid'] = "Partially Paid";
$lang['dashboard_fully_paid'] = "Fully Paid";
$lang['dashboard_cash'] = "Cash";
$lang['dashboard_cheque'] = "Cheque";
$lang['dashboard_paypal'] = "Paypal";
$lang['dashboard_stripe'] = "Stripe";
$lang['dashboard_sample'] = "Sample";
$lang['view'] = "View";