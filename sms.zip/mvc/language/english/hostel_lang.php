<?php

/* List Language  */
$lang['panel_title'] = "Hostel";
$lang['add_title'] = "Add a hostel";
$lang['slno'] = "#";
$lang['hostel_name'] = "Name";
$lang['hostel_htype'] = "Type";
$lang['hostel_address'] = "Address";
$lang['hostel_note'] = "Note";

$lang['select_hostel_type'] = 'Select Type';
$lang['hostel_boys'] = "Boys";
$lang['hostel_girls'] = "Girls";
$lang['hostel_combine'] = "Combine";



$lang['action'] = "Action";
$lang['edit'] = 'Edit';
$lang['delete'] = 'Delete';

/* Add Language */

$lang['add_hostel'] = 'Add Hostel';
$lang['update_hostel'] = 'Update Hostel';