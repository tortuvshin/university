<?php


/* List Language  */
$lang['panel_title'] = "Номнууд";
$lang['add_title'] = "Ном нэмэх";
$lang['slno'] = "#";
$lang['book_name'] = "Нэр";
$lang['book_subject_code'] = "Номны ID";
$lang['book_author'] = "Зохиогч";
$lang['book_price'] = "Үнэ";
$lang['book_quantity'] = "Тоо хэмжээ";
$lang['book_rack_no'] = "Rack No";
$lang['book_status'] = "Статус";
$lang['book_available'] = "Авах боломжтой";
$lang['book_unavailable'] = "Авах боломжгүй";

$lang['action'] = "Үйлдэл";
$lang['view'] = 'Харах';
$lang['edit'] = 'Засах';
$lang['delete'] = 'Устгах';

/* Add Language */

$lang['add_book'] = 'Ном нэмэх';
$lang['update_book'] = 'Номны мэдээлэл шинчлэх';