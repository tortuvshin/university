<?php

$lang['panel_title'] = "Хэрэглэгчийн мэдээлэл";
$lang['profile_roll'] = "ID";
$lang['profile_email'] = "Эмэйл";
$lang['profile_dob'] = "Төрсөн өдөр";
$lang['profile_jod'] = "Бүртгүүлсэн өдөр";
$lang['profile_sex'] = "Хүйс";
$lang['profile_religion'] = "Аймаг/сум";
$lang['profile_phone'] = "Утас";
$lang['profile_address'] = "Хаяг";

$lang['profile_guargian_name'] = "Дүн харагчийн нэр";
$lang['profile_father_name'] = "Эцгийн нэр";
$lang['profile_mother_name'] = "Эхийн нэр";
$lang['profile_father_profession'] = "Эцгийн мэргэжил";
$lang['profile_mother_profession'] = "Эхийн мэргэжил";
$lang['parent_error'] = "Дүн харагч одоогоор бүртгүүлээгүй байна! Дүн харагчийн мэдээллээ нэмнэ үү.";

$lang['personal_information'] = "Хувийн мэдээлэл";
$lang['parents_information'] = "Дүн харагчийн мэдээлэл";
