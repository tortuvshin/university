<?php

/* List Language  */
$lang['panel_title'] = "Нууц үг сэргээх";
$lang['slno'] = "#";
$lang['reset_password_select_users'] = "Хэрэглэгч сонгох";
$lang['reset_password_select_username'] = "Хэрэглэгчийн нэр сонгох";
$lang['reset_password_users'] = "Хэрэглэгчид";
$lang['reset_password_username'] = 'Хэрэглэгчийн нэр';
$lang['reset_password_new_password'] = 'Шинэ нууц үг';
$lang['reset_password_re_password'] = 'Нууц үгээ дахин бичих';

/* Add Language */

$lang['reset_password'] = 'Нууц үг сэргээх';
$lang['update_class'] = 'Курс шинэчлэх';
