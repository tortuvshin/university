<?php
$lang['panel_title'] = "Нүүр";
$lang['dashboard_notice'] = "Мэдээлэл";
$lang['dashboard_username'] = "Хэрэглэгчийн нэр";
$lang['dashboard_email'] = "Эмэйл";
$lang['dashboard_phone'] = "Утас";
$lang['dashboard_address'] = "Хаяг";
$lang['dashboard_libraryfee'] = "Номын сангын төлбөр";
$lang['dashboard_transportfee'] = 'Тээврийн төлбөр';
$lang['dashboard_hostelfee'] = 'Дотуур байрны төлбөр';

$lang['dashboard_earning_graph'] = "Орлогын график";
$lang['dashboard_notpaid'] = "Төлөөгүй";
$lang['dashboard_partially_paid'] = "Хэсэгчлэн төлсөн";
$lang['dashboard_fully_paid'] = "Бүтэн төлсөн";
$lang['dashboard_cash'] = "Cash";
$lang['dashboard_cheque'] = "Cheque";
$lang['dashboard_paypal'] = "Paypal";
$lang['dashboard_stripe'] = "Stripe";
$lang['dashboard_sample'] = "Sample";
$lang['view'] = "Харах";