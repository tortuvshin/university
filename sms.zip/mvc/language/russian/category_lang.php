<?php

/* List Language  */
$lang['panel_title'] = "Ангилал";
$lang['add_title'] = "Ангилал нэмэх";
$lang['slno'] = "#";
$lang['category_hname'] = "Дотуур байрны нэр";
$lang['category_class_type'] = "Курсын төрөл";
$lang['category_hbalance'] = "Дотуур байрны төлбөр";
$lang['category_note'] = "Тэмдэглэл";

$lang['category_select_hostel'] = "Дотуур байр сонгох";

$lang['action'] = "Үйлдэл";
$lang['edit'] = 'Засах';
$lang['delete'] = 'Устгах';

/* Add Language */

$lang['add_category'] = 'Ангилал нэмэх';
$lang['update_category'] = 'Ангилал шинчлэх';