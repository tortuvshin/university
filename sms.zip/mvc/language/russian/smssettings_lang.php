<?php

/* List Language  */
$lang['panel_title'] = "Зурвасны тохиргоо";
$lang['smssettings_username'] = "Хэрэглэгчийн нэр";
$lang['smssettings_password'] = "Нууц үг";
$lang['smssettings_api_key'] = "Api түлхүүр үг";

$lang['smssettings_accountSID'] = "AccountSID";
$lang['smssettings_authtoken'] = "Auth Token";
$lang['smssettings_fromnumber'] = "From Number";

$lang['save'] = "Save";





