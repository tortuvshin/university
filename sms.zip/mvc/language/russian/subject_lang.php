<?php

/* List Language  */
$lang['panel_title'] = "Хичээл";
$lang['add_title'] = "Хичээл нэмэх";
$lang['slno'] = "#";
$lang['subject_class_name'] = "Курсын нэр";
$lang['subject_teacher_name'] = "Багшийн нэр";
$lang['subject_student'] = "Оюутан";
$lang['subject_name'] = "Хичээлийн нэр";
$lang['subject_author'] = "Хичээл үндэслэгч";
$lang['subject_code'] = "Хичээлийн код";
$lang['subject_teacher'] = "Багш";
$lang['subject_classes'] = "Курс";
$lang['subject_select_class'] = "Курс сонгох";
$lang['subject_select_classes'] = "Курс сонгох";
$lang['subject_select_teacher'] = "Багш сонгох";
$lang['subject_select_student'] = "Оюутан сонгох";




$lang['action'] = "Үйлдэл";
$lang['view'] = 'Харах';
$lang['edit'] = 'Засах';
$lang['delete'] = 'Устгах';

/* Add Language */

$lang['add_subject'] = 'Хичээл нэмэх';
$lang['update_subject'] = 'Хичээл шинэчлэх';