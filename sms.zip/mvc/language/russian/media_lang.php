<?php

/* List Language  */
$lang['panel_title'] = "Медиа";
$lang['add_title'] = "Хавтас үүсгэх";
$lang['slno'] = "#";
$lang['media_title'] = "Гарчиг";
$lang['media_date'] = "Огноо";
$lang['action'] = "Үйлдэл";

$lang['view'] = 'Харах';
$lang['edit'] = 'Засах';
$lang['delete'] = 'Устгах';

/* Add Language */

$lang['add_class'] = 'Медиа нэмэх';
$lang['update_class'] = 'Медиа шинэчлэх';
$lang['file'] = 'Медиа';
$lang['upload_file'] = 'Медиа хуулах';
$lang['folder_name'] = 'Хавтасны нэр';
$lang['share'] = 'Хуваалцах';
$lang['share_with'] = 'Share with';
$lang['select_class'] = 'Курс сонгох';
$lang['all_class'] = 'Бүх курс';
$lang['public'] = 'Нийтийн';
$lang['class'] = 'Курс';

