<?php

/* List Language  */
$lang['panel_title'] = "Анги";
$lang['add_title'] = "Анги нэмэх";
$lang['slno'] = "#";
$lang['section_name'] = "Анги";
$lang['section_category'] = "Ангилал";
$lang['section_classes'] = "Курс";
$lang['section_teacher_name'] = "Багшийн нэр";
$lang['section_note'] = "Тэмдэглэл";
$lang['action'] = "Үйлдэл";

$lang['section_select_class'] = "Курс сонгох";
$lang['section_select_teacher'] = "Багш сонгох";

$lang['view'] = 'Харах';
$lang['edit'] = 'Засах';
$lang['delete'] = 'Устгах';

/* Add Language */

$lang['add_class'] = 'Анги нэмэх';
$lang['update_class'] = 'Анги шинэчлэх';