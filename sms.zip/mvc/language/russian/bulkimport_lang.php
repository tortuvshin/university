<?php

/* List Language  */
$lang['panel_title'] = "Импорт";
$lang['add_title'] = "Импорт нэмэх";
$lang['slno'] = "#";
$lang['import_title'] = "Гарчиг";
$lang['import_import'] = "Импорт";
$lang['import_date'] = "Огноо";
$lang['bulkimport_teacher'] = "Багш нэмэх";
$lang['bulkimport_student'] = "Оюутан нэмэх";
$lang['bulkimport_parent'] = "Дүн харагч нэмэх";
$lang['bulkimport_user'] = "Хэрэглэгч нэмэх";
$lang['bulkimport_book'] = "Ном нэмэх";
$lang['bulkimport_submit'] = "Импорт";

/* Add Language */

$lang['add_class'] = 'Импорт нэмэх';
$lang['upload_file'] = 'Файл импортлох';
$lang['import_file_type_error'] = 'Файл алдаатай байна';
$lang['import_error'] = 'Уучлаарай!Мэдээлэл хуулагдсангүй.Дахин оролдоно уу';
$lang['import_success'] = 'Мэдээлэл амжилттай нэмэгдлээ';
$lang['bulkimport_sample'] = 'Жишээ файл татаж авах';