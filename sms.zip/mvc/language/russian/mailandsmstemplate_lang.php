<?php

/* List Language  */
$lang['panel_title'] = "Эмэйл / Зурвас загвар";
$lang['add_title'] = "Загвар нэмэх";
$lang['slno'] = "#";
$lang['mailandsmstemplate_name'] = "Нэр";
$lang['mailandsmstemplate_user'] = "Хэрэглэгч";
$lang['mailandsmstemplate_tags'] = "Tag-ууд";
$lang['mailandsmstemplate_template'] = "Загвар";
$lang['mailandsmstemplate_select_user'] = "Хэрэглэгч сонгох";
$lang['mailandsmstemplate_student'] = "Оюутан";
$lang['mailandsmstemplate_parents'] = "Дүн харагч";
$lang['mailandsmstemplate_teacher'] = "Багш";
$lang['mailandsmstemplate_accountant'] = "Нягтлан бодогч";
$lang['mailandsmstemplate_librarian'] = "Номын санч";
$lang['mailandsmstemplate_type'] = "Төрөл";
$lang['mailandsmstemplate_select_type'] = "Төрөл сонгох";
$lang['mailandsmstemplate_email'] = "Эмэйл";
$lang['mailandsmstemplate_sms'] = "Зурвас";
$lang['mailandsmstemplate_select_tag'] = "Tag сонгох";
$lang['action'] = "Үйлдэл";
$lang['view'] = 'Харах';
$lang['edit'] = 'Засах';
$lang['delete'] = 'Устгах';
$lang['add_template'] = 'Загвар нэмэх';
$lang['update_template'] = 'Загвар шинэчлэх';