<?php

/* List Language  */
$lang['panel_title'] = "Шалгалт";
$lang['add_title'] = "Шалгалт нэмэх";
$lang['slno'] = "#";
$lang['exam_name'] = "Шалгалтын нэр";
$lang['exam_date'] = "Огноо";
$lang['exam_note'] = "Тэмдэглэл";

$lang['action'] = "Үйлдэл";
$lang['view'] = 'Харах';
$lang['edit'] = 'Засах';
$lang['delete'] = 'Устгах';

/* Add Language */

$lang['add_exam'] = 'Шалгалт нэмэх';
$lang['update_exam'] = 'Шалгалтын мэдээлэл шинэчлэх';