<?php

/* List Language  */
$lang['panel_title'] = "Тээвэрлэлт";
$lang['add_title'] = "Тээвэрлэлт нэмэх";
$lang['slno'] = "#";
$lang['transport_route'] = "Хуваарийн нэр";
$lang['transport_vehicle'] = "Машины номер";
$lang['transport_fare'] = "Маршрутын тариф";
$lang['transport_note'] = "Тэмдэглэл";

$lang['action'] = "Үйлдэл";
$lang['view'] = 'Харах';
$lang['edit'] = 'Засах';
$lang['delete'] = 'Устгах';

/* Add Language */

$lang['add_transport'] = 'Тээвэрлэлт нэмэх';
$lang['update_transport'] = 'Тээвэрлэлтийн мэдээлэл шинэчлэх';