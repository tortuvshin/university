<?php

/* List Language  */
$lang['panel_title'] = "Мэйл / Зурвас ";
$lang['add_title'] = "Мэйл / Зурвас нэмэх";
$lang['slno'] = "#";
$lang['mailandsms_users'] = "Хэрэглэгчид";
$lang['mailandsms_select_user'] = "Хэрэглэгч сонгох";
$lang['mailandsms_select_template'] = "Загвар сонгох";
$lang['mailandsms_select_send_by'] = "Илгээх хэрэглэгч сонгох";
$lang['mailandsms_students'] = "Оюутнууд";
$lang['mailandsms_parents'] = "Дүн харагч";
$lang['mailandsms_teachers'] = "Багш нар";
$lang['mailandsms_librarians'] = "Номын санчид";
$lang['mailandsms_accountants'] = "Нягтлан бодогчид";
$lang['mailandsms_template'] = "Загвар";
$lang['mailandsms_type'] = "Төрөл";
$lang['mailandsms_email'] = "Эмэйл";
$lang['mailandsms_sms'] = "Зурвас";
$lang['mailandsms_getway'] = 'Хэнд';
$lang['mailandsms_subject'] = 'Гарчиг';
$lang['mailandsms_message'] = "Зурвас";
$lang['mailandsms_dateandtime'] = "Огноо";


$lang['mailandsms_clickatell'] = "Clickatell";
$lang['mailandsms_twilio'] = "Twilio";
$lang['mailandsms_bulk'] = "Bulk";


$lang['action'] = "Үйлдэл";
$lang['view'] = 'Харах';
$lang['send'] = "Илгээх";
$lang['mail_success'] = 'Эмэйл илгээгдлээ!';
$lang['mail_error'] = 'Уучлаарай! Эмэйл илгээгдсэнгүй!';
$lang['mail_error_user'] = 'Уучлаарай! Хэрэглэгчийн жагсаалт хоосон байна!';





