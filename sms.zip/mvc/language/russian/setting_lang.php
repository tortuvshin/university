<?php

/* List Language  */
$lang['panel_title'] = "Тохиргоо";
$lang['add_title'] = "Тохиргоо өөрчлөх";

$lang['setting_school_name'] = "Сайтын гарчиг";
$lang['setting_school_phone'] = "Утасны дугаар";
$lang['setting_school_email'] = "Системийн эмэйл";
$lang['setting_school_address'] = "Хаяг";
$lang['setting_school_currency_code'] = "Мөнгөн тэмдэгтийн код";
$lang['setting_school_currency_symbol'] = "Мөнгөн тэмдэгт";
$lang['setting_school_automation'] = "Автоматжуулалт";
$lang['setting_school_footer'] = "Footer";
$lang['setting_school_attendance'] = "Ирц";
$lang['setting_school_select_attendance'] = "Ирцийн систем сонгох";
$lang['setting_school_select_day_attendance'] = "Өдрөөр ангилсан ирц";
$lang['setting_school_select_subject_attendance'] = "Хичээлээр ангилсан ирц";
$lang['setting_school_lang'] = "Үндсэн хэл";
$lang['setting_school_photo'] = "Лого";
$lang['setting_english'] = "Англи";
$lang['setting_bengali'] = "Бенгали";
$lang['setting_arabic'] = "Араб";
$lang['setting_chinese'] = "Хятад";
$lang['setting_french'] = "Франц";
$lang['setting_german'] = "Герман";
$lang['setting_hindi'] = "Энэтхэг";
$lang['setting_indonesian'] = "Индонез";
$lang['setting_italian'] = "итали";
$lang['setting_romanian'] = "Рум";
$lang['setting_russian'] = "Монгол";
$lang['setting_spanish'] = "Испани";
$lang['setting_thai'] = "Тайланд";
$lang['setting_turkish'] = "Түрк";


/*edit */
$lang['update_setting'] = 'Тохиргоог шинэчлэх';
$lang['upload_setting'] = 'Хуулах';
$lang['settings_pde'] = "Таны бүтээгдэхүүний нууц код буруу байна.";

