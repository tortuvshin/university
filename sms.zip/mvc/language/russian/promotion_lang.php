<?php

$lang['panel_title'] = "Анги дэвшилт";
$lang['add_title'] = "Анги дэвшилт нэмэх";
$lang['slno'] = "#";
$lang['promotion_photo'] = "Зураг";
$lang['promotion_name'] = "Нэр";
$lang['promotion_section'] = "Анги";
$lang['promotion_result'] = "Үр дүн";
$lang['promotion_pass'] = "Давсан";
$lang['promotion_fail'] = "Унасан";
$lang['promotion_modarate'] = "Хараахан болоогүй";
$lang['promotion_phone'] = "Утас";
$lang['promotion_classes'] = "Курс";
$lang['promotion_roll'] = "ID";
$lang['promotion_create_class'] = "Шинэ анги үүсгэнэ үү";
$lang['promotion_select_class'] = "Курс сонгох";
$lang['promotion_select_student'] = "Оюутан сонгох";
$lang['add_all_promotion'] = "Бүх анги дэвшилт";
$lang['promotion_alert'] = "Санамж";
$lang['promotion_ok'] = "Ok";
$lang['promotion_success'] = "Анги дэвшилт амжилттай боллоо";
$lang['promotion_emstudent'] = "Оюутны жагсаалт хоосон байна";


$lang['action'] = "Үйлдэл";

$lang['add_mark_setting'] = 'Анги дэвшилтийн дүнгийн тохируулга';
$lang['add_promotion'] = 'Дараагын ангируу дэвшүүлэх';
