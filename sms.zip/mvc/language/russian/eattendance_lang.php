<?php

/* List Language  */
$lang['panel_title'] = "Шалгалтын ирц";
$lang['add_title'] = "Шалгалтын ирц нэмэх";
$lang['slno'] = "#";
$lang['eattendance_photo'] = "Зураг";
$lang['eattendance_name'] = "Нэр";
$lang['eattendance_email'] = "Эмэйл";
$lang['eattendance_roll'] = "ID";
$lang['eattendance_phone'] = "Утас";
$lang['eattendance_attendance'] = "Ирц";
$lang['eattendance_section'] = "Анги";
$lang['eattendance_exam'] = "Шалгалт";
$lang['eattendance_classes'] = "Курс";
$lang['eattendance_subject'] = "Хичээл";
$lang['eattendance_all_students'] = 'Бүх оюутнууд';

$lang['eattendance_select_exam'] = "Шалгалт сонгох";
$lang['eattendance_select_classes'] = "Курс сонгох";
$lang['eattendance_select_subject'] = "Хичээл сонгох";


$lang['action'] = "Үйлдэл";

/* Add Language */

$lang['add_attendance'] = 'Ирц';
$lang['add_all_attendance'] = 'Бүх ирц нэмэх';
$lang['view_attendance'] = "Ирц харах";