<?php

/* List Language  */
$lang['panel_title'] = "Дотуур байр";
$lang['add_title'] = "Дотуур байр нэмэх";
$lang['slno'] = "#";
$lang['hostel_name'] = "Нэр";
$lang['hostel_htype'] = "Төрөл";
$lang['hostel_address'] = "Хаяг";
$lang['hostel_note'] = "Тэмдэглэл";

$lang['select_hostel_type'] = 'Төрөл сонгох';
$lang['hostel_boys'] = "Эрэгтэй";
$lang['hostel_girls'] = "Эмэгтэй";
$lang['hostel_combine'] = "Нийт";



$lang['action'] = "Үйлдэл";
$lang['edit'] = 'Засах';
$lang['delete'] = 'Устгах';

/* Add Language */

$lang['add_hostel'] = 'Дотуур байр нэмэх';
$lang['update_hostel'] = 'Дотуур байрын мэдээлэл шинэчлэх';