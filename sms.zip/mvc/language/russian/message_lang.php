<?php

/* List Language  */
$lang['panel_title'] = "Зурвас";
$lang['add_title'] = "Шинээр үүсгэх";
$lang['folder'] = "Хавтаснууд";
$lang['inbox'] = "Зурвасны хайрцаг";
$lang['to'] = "Хэнд";
$lang['status'] = "Статус";
$lang['name'] = "Нэр";
$lang['subject'] = "Гарчиг";
$lang['attach'] = "Attach";
$lang['time'] = "Цаг";
$lang['sent'] = "Явуулсан";
$lang['trash'] = "Хогын сав";
$lang['favorite'] = "Чухал";
$lang['slno'] = "#";
$lang['message_title'] = "Гарчиг";
$lang['message_message'] = "Зурвас";
$lang['message_date'] = "Огноо";
$lang['action'] = "Үйлдэл";
$lang['read_message'] = "Зурвас унших";
$lang['reply'] = "Хариулах";
$lang['compose_new'] = "Шинэ зурвас үүсгэх";
$lang['admin_select_label'] = "Admin жагсаалт";
$lang['student_select_label'] = "Оюутны жагсаалт";
$lang['parent_select_label'] = "Дүн харагчийн жагсаалт";
$lang['teacher_select_label'] = "Багш нарын жагсаалт";
$lang['librarian_select_label'] = "Номын санчидын жагсаалт";
$lang['accountant_select_label'] = "Нягтлан бодогчдын жагсаалт";
$lang['attachment'] = "Attachment";
$lang['send'] = "Илгээх";
$lang['close'] = "Хаах";
$lang['sender'] = "Илгээсэн";
$lang['discard'] = "Болих";
$lang['error'] = "Хариу илгээгдсэнгүй!";

