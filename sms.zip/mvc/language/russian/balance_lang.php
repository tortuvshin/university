<?php

/* List Language  */
$lang['panel_title'] = "Төлбөр";
$lang['slno'] = "#";
$lang['balance_classesID'] = "Курс";
$lang['balance_select_classes'] = "Курсээ сонгох";
$lang['balance_all_students'] = 'Бүх оюутнууд';
$lang['balance_photo'] = "Зураг";
$lang['balance_name'] = "Нэр";
$lang['balance_roll'] = "ID";
$lang['balance_phone'] = "Утас";
$lang['balance_totalbalance'] = "Нийт төлбөр";