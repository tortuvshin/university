<?php

/* List Language  */
$lang['panel_title'] = "Дүнгийн зэрэг";
$lang['add_title'] = "Дүнгийн зэрэг нэмэх";
$lang['slno'] = "#";
$lang['grade_name'] = "Дүнгийн зэрэг нэр";
$lang['grade_point'] = "Голч";
$lang['grade_gradefrom'] = "Эхлэх оноо";
$lang['grade_gradeupto'] = "Дуусах оноо";
$lang['grade_note'] = "Тэмдэглэл";

$lang['action'] = "Үйлдэл";
$lang['view'] = 'Харах';
$lang['edit'] = 'Засах';
$lang['delete'] = 'Устгах';

/* Add Language */

$lang['add_class'] = 'Дүнгийн зэрэг нэмэх';
$lang['update_class'] = 'Дүнгийн зэрэг шинэчлэх';