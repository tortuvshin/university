<?php

/* List Language  */
$lang['panel_title'] = "Курс";
$lang['add_title'] = "Курс нэмэх";
$lang['slno'] = "#";
$lang['classes_name'] = "Курс";
$lang['classes_numeric'] = "Курсын дугаар";
$lang['teacher_name'] = "Багшийн нэр";
$lang['classes_note'] = "Тэмдэглэл";
$lang['action'] = "Үйлдэл";

$lang['classes_select_teacher'] = "Багш сонгох";

$lang['view'] = 'Үзэх';
$lang['edit'] = 'Засах';
$lang['delete'] = 'Устгах';

/* Add Language */

$lang['add_class'] = 'Курс нэмэх';
$lang['update_class'] = 'Курс шинэчлэх';