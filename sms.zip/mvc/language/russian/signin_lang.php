<?php

/* List Language  */
$lang['signin'] = "Нэвтрэх хэсэг";
$lang['signin_remember_me'] = "Намайг сана";
$lang['signin_username'] = "Хэрэглэгчийн нэр";
$lang['signin_password'] = "Нууц үг";
$lang['signin_forgot'] = "Нууц үг сэргээх";
$lang['signin_value'] = "НЭВТРЭХ";

