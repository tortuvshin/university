<?php

/* List Language  */
$lang['panel_title'] = "Төлбөрийн төрөл";
$lang['add_title'] = "Төлбөрийн төрөл нэмэх";
$lang['slno'] = "#";
$lang['feetype_name'] = "Төлбөрийн төрөл";
$lang['feetype_note'] = "Тэмдэглэл";
$lang['action'] = "Үйлдэл";

$lang['edit'] = 'Засах';
$lang['delete'] = 'Устгах';

/* Add Language */
$lang['add_feetype'] = 'Төлбөрийн төрөл нэмэх';
$lang['update_feetype'] = 'Төлбөрийн төрөл шинэчлэх';