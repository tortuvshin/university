<?php

/* List Language  */
$lang['panel_title'] = "Зардал";
$lang['add_title'] = "Зардал нэмэх";
$lang['slno'] = "#";
$lang['expense_expense'] = "Нэр";
$lang['expense_date'] = "Огноо";
$lang['expense_amount'] = "Хэмжээ";
$lang['expense_note'] = "Тэмдэглэл";
$lang['expense_uname'] = "Хэрэглэгч";
$lang['expense_total'] = "Нийт";
$lang['action'] = "Үйлдэл";

// $lang['view'] = 'View';
$lang['edit'] = 'Засах';
$lang['delete'] = 'Устгах';

/* Add Language */

$lang['add_expense'] = 'Зардал нэмэх';
$lang['update_expense'] = 'Зардал шинэчлэх';